package com.hacker.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.hacker.controllers.TestController;
import com.hacker.rest.HackerRankRestController;
import com.hacker.services.NewUserService;

/*@Configuration
@ComponentScan({"com.hacker"})
@EnableWebMvc
@EnableAutoConfiguration
*/
@SpringBootApplication
public class App extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		// TODO Auto-generated method stub
		return builder.sources(App.class);
	}
	
	@Bean
	public HackerRankRestController hackerRankRestController(){
		return new HackerRankRestController();
	}
	
	@Bean
	public TestController testController(){
		return new TestController();
	}
	@Bean
	public NewUserService newUserService(){
		return new NewUserService();
	}
	@Bean
	public UrlBasedViewResolver setUpViewResolver(){
		UrlBasedViewResolver resolver=new UrlBasedViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		
		return resolver;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SpringApplication.run(App.class, args);
	}

}
