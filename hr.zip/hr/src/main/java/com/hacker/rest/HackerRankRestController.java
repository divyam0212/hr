package com.hacker.rest;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;
import com.hacker.model.ResponseTransfer;
import com.hacker.services.NewUserService;
import com.hacker.util.ConnectionUserUtil;

//@RequestMapping("/emp/data")
@RestController
@CrossOrigin
public class HackerRankRestController {

	@Autowired(required=true)
	NewUserService newUserService;
	public HackerRankRestController() {
		// TODO Auto-generated constructor stub
	}
	
	@PostMapping("/saveuser")
	public ResponseTransfer postEmp(@RequestBody NewUser newUser) {
		
		Connection connObj = null;
		ResponseTransfer responseTransfer = new ResponseTransfer();
		String msg = "";
		int count = 0;
		try {
			connObj = ConnectionUserUtil.getConnection();
			count = newUserService.registerUser(connObj, newUser);
			if (count > 0) {
				msg = "success" + count;
			}
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			msg = e.getMessage();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			msg = e.getMessage();
		}
		responseTransfer.setMesssage(msg);
		return responseTransfer;
	}
	
	@GetMapping("/all")
	public List<NewUser> getAllUser(){
		Connection connection=null;
		List<NewUser> listNewUser=new ArrayList<NewUser>();
		try{
			connection=ConnectionUserUtil.getConnection();
			listNewUser=newUserService.fetchAllUsers(connection, "null");
			System.out.println(listNewUser);
		}
		catch (UserNotFoundException notFound) {
			notFound.printStackTrace();
		}
		catch(SQLException sql){
			sql.printStackTrace();
		}
		finally{
			try{
				if(connection!=null){
					connection.close();
				}
			}
			catch(SQLException sql){
				sql.printStackTrace();
			}
		}
		return listNewUser;
	}
	@GetMapping("/getUser/{userId}")
	public NewUser getById(@PathVariable int userId){
		Connection connection=null;
		NewUser newUser=new NewUser();
		try{
			connection=ConnectionUserUtil.getConnection();
			newUser=newUserService.fetchAllUserById(connection, userId);
		}
		catch (UserNotFoundException notFound) {
			notFound.printStackTrace();
		}
		catch(SQLException sql){
			sql.printStackTrace();
		}
		finally{
			try{
				if(connection!=null){
					connection.close();
				}
			}
			catch(SQLException sql){
				sql.printStackTrace();
			}
		}
		return newUser;
	}
	@PostMapping("/checkUser")
	public ResponseTransfer loginCheck(@RequestBody NewUser newUser) {
			
			Connection connObj = null;
			ResponseTransfer responseTransfer = new ResponseTransfer();
			String msg = "";
			boolean count=false;
			try {
				connObj = ConnectionUserUtil.getConnection();
				count = newUserService.loginNewUserCheck(connObj, newUser);
				if (count) {
					msg = "success " + count;
				}
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				msg = e.getMessage();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				msg = e.getMessage();
			}
			responseTransfer.setMesssage(msg);
			return responseTransfer;
		}
}
