package com.hacker.controllers;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;
import com.hacker.util.ConnectionUserUtil;
import com.hacker.services.NewUserService;

@ComponentScan({"com.hacker"})
@SessionAttributes("newUser")
@Controller
public class TestController {

	public TestController() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/home")
	public String home(HttpServletRequest request)
	{
		System.out.println("HOME");
		request.getSession(true).invalidate();
		String path="loginhr";
		if(request.getSession().getAttribute("newUser")==null){
			
		}
		else{
			path="welcome";
		}
		return path;
		
	}
	@PostMapping("/LoginController")
	public ModelAndView login(NewUserService newUserService,NewUser newUser,ModelAndView modelAndView)
	{
		System.out.println("LOGIN DETAILS"+newUser);
		String path="welcome";
		Connection connObj=null;
		boolean flag=false;
		try{
			connObj=ConnectionUserUtil.getConnection();
			connObj.setAutoCommit(false);
			flag=newUserService.loginNewUserCheck(connObj, newUser);
			if(flag){
				modelAndView.setViewName(path);
				System.out.println("User Logged In");
				modelAndView.addObject("user", newUser);
			}
			else{
				path="loginhr";
				modelAndView.setViewName(path);
				modelAndView.addObject("error","INVALID CREDENTIALS... PLEASE CHECK USERNAME OR PASSWORD");
			}
		}
		catch (UserNotFoundException notFound) {
			// TODO Auto-generated catch block
			/*e.printStackTrace();*/
			modelAndView.addObject("error", "SOME INTERNAL DATABASE ERROR");
		}
		catch( SQLException e)
		{
			try{
				connObj.rollback();
			}
			catch(SQLException e1)
			{
				//e1.printStackTrace();
				System.out.println(e1.getMessage());
			}
		}
		finally
		{
			try
			{
				if(connObj!=null)
				{
					connObj.close();
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				System.out.println("Error in closing file");
			}
		}
		return modelAndView;
		
	}
	@GetMapping("/register")
	public String register(@ModelAttribute NewUser newUser)
	{
		return "signuphr";
	}
	@PostMapping("/RegistrationController")
	public ModelAndView register(NewUser newUser,NewUserService newUserService,ModelAndView modelAndView){
		System.out.println(newUser);
		boolean flag=false;
		Connection connObj=null;
		try{
			connObj=ConnectionUserUtil.getConnection();
			connObj.setAutoCommit(false);
			
			flag=newUserService.loginNewUserCheck(connObj, newUser);
			modelAndView.setViewName("signuphr");
			if(flag){
				modelAndView.addObject("existUser", "USER ALREADY EXISTS!! TRY LOGGING IN...");
			}
			else{
				int userId=newUserService.registerUser(connObj, newUser);
				newUser.setUserId(userId);
				String credential="YOUR EMPLOYEE ID: "+userId;
				
				modelAndView.addObject("success", "SUCCESSFUL REGISTRATION");
				modelAndView.addObject("rem", "REMEMBER YOUR CREDENTIALS FOR FUTURE");
				modelAndView.addObject("credentials", credential);
				
			}
			connObj.commit();
		}
		catch(UserNotFoundException notFound){
			notFound.printStackTrace();
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		finally
		{
			try{
				
				if(connObj!=null)
				{
					connObj.close();
				}
			}
			catch(SQLException sqle)
			{
				sqle.printStackTrace();
			}
			
		}
		return modelAndView;
	}
	@GetMapping("/welcome")
	public String welcome(){
		return "welcome";
	}
	@GetMapping("/logout")
	public String logout(HttpServletRequest request){
		request.getSession(true).invalidate();
		return "loginhr";
	}
}
