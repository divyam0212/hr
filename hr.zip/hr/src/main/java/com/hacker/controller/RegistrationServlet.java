package com.hacker.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;
import com.hacker.util.ConnectionUserUtil;
import com.hacker.services.NewUserService;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String userName = request.getParameter("firstname");
		String email = request.getParameter("username");
		String password = request.getParameter("password");

		String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
		NewUser newUser = new NewUser(userName, email, password);
		boolean check = false;
		Connection connObj = null;
		try {
			connObj = ConnectionUserUtil.getConnection();
			connObj.setAutoCommit(false);

			NewUserService userDao = new NewUserService();
			if (!(password.matches(pattern))) 
			{
				throw new UserNotFoundException("Password is wrong");
			} 
			else if (userName == "") {
					throw new UserNotFoundException("Name must be filled");
			}
			else if (email == "") 
			{
					throw new UserNotFoundException("Email must be filled");
			}
			else if (password == "") 
			{
					throw new UserNotFoundException("Password must be filled");
			}
			else{
					check = userDao.loginNewUserCheck(connObj, newUser);
					if (check) {
						request.setAttribute("existUser", "USER ALREADY EXISTS!! TRY LOGGING IN...");
					} else 
						{
							int userId = userDao.registerUser(connObj, newUser);
							newUser.setUserId(userId);
							if (userId != 0) 
							{
								String credential = "YOUR EMPLOYEE ID: " + userId;
								/*
								 * out.println("SUCCESSFUL REGISTRATION");
								 * out.println("YOUR EMPLOYEE ID: "+userId);
								 * out.println("PLEASE REMEMBER FOR FUTURE!!");
								 */
								request.setAttribute("success", "SUCCESSFUL REGISTRATION");
								request.setAttribute("rem", "REMEMBER YOUR CREDENTIALS FOR FUTURE");
								request.setAttribute("credentials", credential);
							}
						}
					connObj.commit();
					RequestDispatcher rd = request.getRequestDispatcher("signuphr.jsp");
					rd.forward(request, response);
			}
			
			
		} catch (UserNotFoundException notFound) {
			notFound.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {

				if (connObj != null) {
					connObj.close();
				}
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}

		}
	}
		
	
}

