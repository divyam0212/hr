package com.hacker.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;
import com.hacker.util.ConnectionUserUtil;
import com.hacker.services.NewUserService;

/**
 * Servlet implementation class NewUserServlet
 */
@WebServlet("/NewUserServlet")
public class NewUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String emailId=request.getParameter("email");
		String password=request.getParameter("password");
		
		String page="loginhr.jsp";
		Connection connObj=null;
		boolean check=false;
		NewUserService userDao=null;
		try
		{
			connObj	=ConnectionUserUtil.getConnection();
			connObj.setAutoCommit(false);
			
			NewUser login=new NewUser(emailId,password);
			userDao=new NewUserService();
			check=userDao.loginNewUserCheck(connObj, login);
			
			if(check)
			{
				HttpSession session=request.getSession();
				session.setAttribute("user", login);
				System.out.println("User logged in");
				
				page="welcome.jsp";
				request.setAttribute("user",login);
			}
			else
			{
				page="loginhr.jsp";
				request.setAttribute("error","INVALID CREDENTIALS... PLEASE CHECK USERNAME OR PASSWORD");
			}
			RequestDispatcher rd=request.getRequestDispatcher(page);
			rd.forward(request, response);
			
		}
		catch (UserNotFoundException notFound) {
			// TODO Auto-generated catch block
			/*e.printStackTrace();*/
			request.setAttribute("error", "Some Internal DataBase Error");
		}
		catch( SQLException e)
		{
			try{
				connObj.rollback();
			}
			catch(SQLException e1)
			{
				//e1.printStackTrace();
				System.out.println(e1.getMessage());
			}
		}
		finally
		{
			try
			{
				if(connObj!=null)
				{
					connObj.close();
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				System.out.println("Error in closing file");
			}
		}
	}

}
