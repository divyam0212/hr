package com.hacker.services;

import java.sql.Connection;
import java.util.List;

import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;

public interface INewUser {
	public boolean loginNewUserCheck(Connection connection, NewUser newUser) throws UserNotFoundException;
	public int registerUser(Connection connObj, NewUser newUser) throws UserNotFoundException;
	public NewUser fetchAllUserById(Connection connection, int userId);
	public List<NewUser> fetchAllUsers(Connection connection, String name);
}
