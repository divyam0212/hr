package com.hacker.services;

import java.sql.Connection;
import java.util.List;

import org.springframework.stereotype.Service;

import com.hacker.dao.NewUserDAO;
import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;

@Service
public class NewUserService implements INewUser {

	NewUserDAO newUserDao=null;
	public NewUserService() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean loginNewUserCheck(Connection connection, NewUser newUser) throws UserNotFoundException {
		newUserDao=new NewUserDAO();
		boolean flag=newUserDao.loginNewUserCheck(connection, newUser);
		return flag;
	}

	public int registerUser(Connection connObj, NewUser newUser) throws UserNotFoundException {
		newUserDao=new NewUserDAO();
		int generatedKey=newUserDao.registerUser(connObj, newUser);
		return generatedKey;
	}

	public NewUser fetchAllUserById(Connection connection, int userId) {
		newUserDao=new NewUserDAO();
		NewUser newUser=newUserDao.fetchAllUserById(connection, userId);
		return newUser;
	}

	public List<NewUser> fetchAllUsers(Connection connection, String name) {
		newUserDao=new NewUserDAO();
		List<NewUser> listUser=newUserDao.fetchAllUsers(connection,name);
		return listUser;
	}
	

}
