package com.hacker.util;

public class EncryDecryPassword {

	public EncryDecryPassword() {
		// TODO Auto-generated constructor stub
	}

}
