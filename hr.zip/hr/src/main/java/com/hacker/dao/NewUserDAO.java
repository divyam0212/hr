package com.hacker.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hacker.exception.UserNotFoundException;
import com.hacker.model.NewUser;

public class NewUserDAO {

	public NewUserDAO() {
		// TODO Auto-generated constructor stub
	}
	public boolean loginNewUserCheck(Connection connection,NewUser newUser) throws UserNotFoundException
	{
			boolean flag=false;
			//Connection connObj=null;
			PreparedStatement pstmt=null;
			String query="select * from user where email_id=? and password=?";
			ResultSet rs=null;
			try 
			{
				//connection=ConnectionUtil.getConnection();
				//use PrepareStatement because where clause is used and is used each time
				connection.setAutoCommit(false);
				pstmt=connection.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
				
				pstmt.setString(1,newUser.getEmailId());	// getting username and password from logindetails parameter
				pstmt.setString(2,newUser.getPassword());
				
				rs=pstmt.executeQuery();
				if(rs.next())
				{
					flag=true;
				}
				connection.commit();
			} 
			catch (SQLException e) 
			{
				throw new UserNotFoundException("SQL EXCEPTION");
				/*System.out.println(e);
				e.printStackTrace();*/
			}
			finally
			{
				try{
					if (rs != null) 
					{
						rs.close();
					} 
					if (pstmt != null) 
					{
						pstmt.close();
					}
					/*if (connObj != null) 
					{
						connObj.close();
					} */	
				}
				catch (SQLException e) 
				{
					 	throw new UserNotFoundException("SQL EXCEPTION");
						//System.out.println("Error While Closing Connection");
				}
			}
			return flag;
	}
	public int registerUser(Connection connObj,NewUser newUser) throws UserNotFoundException
	{
		int generatedId=0;
		String query="insert into user(user_name,email_id,password) values(?,?,?);";
		PreparedStatement pstmt=null;
		ResultSet result=null;
		try{
			connObj.setAutoCommit(false);
			pstmt=connObj.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1,newUser.getUserName());
			pstmt.setString(2, newUser.getEmailId());
			pstmt.setString(3,newUser.getPassword());
			
			pstmt.executeUpdate();
			result=pstmt.getGeneratedKeys();
			if(result.next())
			{
				generatedId=result.getInt(1);
			}
			connObj.commit();
		}
		catch (SQLException e) 
		{
			System.out.println(e);
			e.printStackTrace();
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				throw new UserNotFoundException("SQL EXCEPTION");
				//e1.printStackTrace();
			}
		}
		finally
		{
			try{
				if (result != null) 
				{
					result.close();
				} 
				if (pstmt != null) 
				{
					pstmt.close();
				} 	
			}
			catch (SQLException e) 
			{
					throw new UserNotFoundException("SQL EXCEPTION");
					//System.out.println("Error While Closing Connection");
			}
		}
		return generatedId;
		
	}
	public List<NewUser> fetchAllUsers(Connection connection, String name){
		List<NewUser> listUsers=new ArrayList<NewUser>();
		
		String query="select * from user;";
		String query1="select * from user where user_name like ?;";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		
		try{
			connection.setAutoCommit(false);
			if(name.equals("null")){
				pstmt = connection.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
			}
			else{
				pstmt=connection.prepareStatement(query1);
				pstmt.setString(1, "%" + name + "%");
			}
			result = pstmt.executeQuery();
			while(result.next()){
				int userId=result.getInt("user_id");
				String userName=result.getString("user_name");
				String email=result.getString("email_id");
				String password=result.getString("password");
				NewUser newUser=new NewUser(userId,userName,email,password);
				listUsers.add(newUser);
			}
			connection.commit();
		}
		catch(SQLException sql){
			sql.printStackTrace();
		}
		finally 
		{
			try 
			{
				if (result != null) 
				{
					result.close();
				}
				if (pstmt != null) 
				{
					pstmt.close();
				}
			} 
			catch (SQLException sqle) 
			{
				sqle.printStackTrace();
			}

		}
		return listUsers;
	}
	
	public NewUser fetchAllUserById(Connection connection, int userId){
		NewUser newUser=new NewUser();
		
		String query="select * from user where user_id=?;";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		
		try{
			connection.setAutoCommit(false);
			pstmt=connection.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, userId);
			result = pstmt.executeQuery();
			while(result.next())
			{
				String userName=result.getString("user_name");
				String email=result.getString("email_id");
				String password=result.getString("password");
				newUser.setUserId(userId);
				newUser.setUserName(userName);
				newUser.setEmailId(email);
				newUser.setPassword(password);
			}
			connection.commit();
		}
		catch(SQLException sql){
			sql.printStackTrace();
		}
		finally 
		{
			try 
			{
				if (result != null) 
				{
					result.close();
				}
				if (pstmt != null) 
				{
					pstmt.close();
				}
			} 
			catch (SQLException sqle) 
			{
				sqle.printStackTrace();
			}

		}
		return newUser;
	}
}
